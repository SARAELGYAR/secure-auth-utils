const crypto = require('crypto');

function hashPassword(password) {
  if (typeof password !== 'string') {
    throw new TypeError('Password must be a string');
  }

  const salt = crypto.randomBytes(16);
  
  const hash = crypto.pbkdf2Sync(
    password,
    salt,
    100000,
    64,
    'sha512'
  );

  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

function verifyPassword(password, storedHash) {
  if (typeof password !== 'string' || typeof storedHash !== 'string') {
    throw new TypeError('Password and storedHash must be strings');
  }

  const [saltHex, hashHex] = storedHash.split(':');
  
  if (!saltHex || !hashHex) {
    throw new Error('Invalid stored hash format');
  }

  const salt = Buffer.from(saltHex, 'hex');
  const storedHashBuf = Buffer.from(hashHex, 'hex');

  const computedHash = crypto.pbkdf2Sync(
    password,
    salt,
    100000,
    64,
    'sha512'
  );

  return crypto.timingSafeEqual(storedHashBuf, computedHash);
}

module.exports = {
  hashPassword,
  verifyPassword
};