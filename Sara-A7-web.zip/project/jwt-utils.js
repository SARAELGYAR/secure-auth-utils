const crypto = require('crypto');

function base64UrlEncode(data) {
  let buffer;
  if (Buffer.isBuffer(data)) {
    buffer = data;
  } else if (typeof data === 'string') {
    buffer = Buffer.from(data);
  } else {
    throw new TypeError('Data must be a string or Buffer');
  }

  return buffer.toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function base64UrlDecode(str) {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  
  while (base64.length % 4) {
    base64 += '=';
  }
  
  return Buffer.from(base64, 'base64');
}

function signJWT(payload, secret, expiresInSeconds = 3600) {
  if (typeof payload !== 'object' || payload === null) {
    throw new TypeError('Payload must be an object');
  }
  if (typeof secret !== 'string' || !secret) {
    throw new TypeError('Secret must be a non-empty string');
  }
  if (typeof expiresInSeconds !== 'number' || expiresInSeconds <= 0) {
    throw new TypeError('expiresInSeconds must be a positive number');
  }

  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const currentTimestamp = Math.floor(Date.now() / 1000);
  const payloadWithExp = {
    ...payload,
    exp: currentTimestamp + expiresInSeconds
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payloadWithExp));

  const dataToSign = `${encodedHeader}.${encodedPayload}`;

  const signature = crypto
    .createHmac('sha256', secret)
    .update(dataToSign)
    .digest();

  return `${dataToSign}.${base64UrlEncode(signature)}`;
}

function verifyJWT(token, secret) {
  if (typeof token !== 'string') {
    throw new TypeError('Token must be a string');
  }
  if (typeof secret !== 'string' || !secret) {
    throw new TypeError('Secret must be a non-empty string');
  }

  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Invalid token format');
  }

  const [encodedHeader, encodedPayload, encodedSignature] = parts;

  const dataToVerify = `${encodedHeader}.${encodedPayload}`;
  const signature = base64UrlDecode(encodedSignature);
  
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(dataToVerify)
    .digest();

  if (!crypto.timingSafeEqual(signature, expectedSignature)) {
    throw new Error('Invalid token signature');
  }

  const payload = JSON.parse(base64UrlDecode(encodedPayload).toString());

  const currentTimestamp = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < currentTimestamp) {
    throw new Error('Token has expired');
  }

  return payload;
}

module.exports = {
  signJWT,
  verifyJWT
};