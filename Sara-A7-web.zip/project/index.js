const { hashPassword, verifyPassword } = require('./password-utils');
const { signJWT, verifyJWT } = require('./jwt-utils');

// Test password utilities
const password = 'TestPassword123!';
console.log('Testing password utilities:');
const hashedPassword = hashPassword(password);
console.log('Hashed password:', hashedPassword);
console.log('Verification result:', verifyPassword(password, hashedPassword));

// Test JWT utilities
const payload = { userId: '123', role: 'user' };
console.log('\nTesting JWT utilities:');
const token = signJWT(payload, 'secret', 3600);
console.log('Generated token:', token);
console.log('Decoded payload:', verifyJWT(token, 'secret'));